(function(window, undefined) {
	var f = window.Frontender;
	f.$script.ready(['jquery', '_', 'backbone'], function() {
		f.ProjectItem = f.Backbone.Model.extend({});
	});
}(this, void 0))